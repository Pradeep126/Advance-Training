package program1two;

		public class Rectangle {
		    float area;
		    public Rectangle(float length,float width) {
		     area=length*width;
	        System.out.println("area of the rectangle is "+area);
	        System.out.println("informations of rectangle");
			System.out.println("length = "+length+"  width  = "+width+"  area = "+area);
		}
	

}
