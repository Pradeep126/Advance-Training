package program2three;

public class integerArray {  
	
		public static void main(String[] args) {
			int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};   //17
			int len= A.length;
			int sum= 0;
			
			for(int i=0; i<=14;i++) {
				sum=A[i]+sum;
				
			}
			A[15]= sum;
			System.out.println(A[15]);
			//avg
			A[16]=sum/len;
			System.out.println(A[16]);
			
			//minimum number
			A[17]= sort(A);
			System.out.println(A[17]);
			
			//printing elements from array
			for(int i=0; i<A.length;i++) {
				System.out.print(i+" :"+A[i]+" ,");
			}
			
		}

		private static int sort(int[] array) {
			int min =array[0];
			for(int i =0; i<=14; i++) {
				if(array[i]<min) {
					min=array[i];
				}
			}
			return min;
		}
		}
