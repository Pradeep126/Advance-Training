package program3one;

public abstract class Instrument
{
public abstract void Play();
}